from django.contrib import admin
from .models import fdata , questions

admin.site.register(fdata)
admin.site.register(questions)
