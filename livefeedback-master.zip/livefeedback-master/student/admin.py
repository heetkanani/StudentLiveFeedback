from django.contrib import admin
from .models import sdata , submissiondata

admin.site.register(sdata)
admin.site.register(submissiondata)
